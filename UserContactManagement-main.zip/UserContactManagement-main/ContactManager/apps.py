from django.apps import AppConfig


class ContactmanagerConfig(AppConfig):
    name = 'ContactManager'
